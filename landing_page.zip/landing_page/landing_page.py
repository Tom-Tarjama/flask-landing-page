from flask import Flask, render_template

landing_page = Flask(__name__)

@landing_page.route("/")

def landing_page_root():
	return render_template("index.html")

@landing_page.route("/ninjas")

def landing_page_ninjas():
	return render_template("ninjas.html")

@landing_page.route("/dojos/new")

def landing_page_form():
	return render_template("dojos.html")

# @landing_page.route("/dojos/new", methods=['POST'])

# def landing_page_form():
# 	return render_template("dojos.html")

landing_page.run(debug=True)
